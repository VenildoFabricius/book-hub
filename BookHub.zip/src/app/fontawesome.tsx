import { config } from "@fortawesome/fontawesome-svg-core";
import '@fortawesome/fontawesome-svg-core';

config.autoAddCss = false;

export default function FontAwesomeConfig() {
    return null;
}