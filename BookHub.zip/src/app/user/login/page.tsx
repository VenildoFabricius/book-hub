import LoginForm from "@/components/form-login"

export default function Login() {
    return (
        <LoginForm />
    )
}