import CreateUserForm from "@/components/form-create";

export default function Create() {
    return (
        <CreateUserForm />
    );
}